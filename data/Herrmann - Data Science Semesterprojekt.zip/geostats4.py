__author__ = "7157903, Herrmann"
__credits__ = "1.8 Einfache Rechnungen in einem Package"
__email__ = "david.herrmann@stud.uni-frankfurt.de" 


# Package import für das geostats-Package
import pandas as pd
import shutil
import mag4 as data
import mag4 as mg
import math
import matplotlib.pyplot as plt
from ipywidgets import interact, widgets
import numpy as np
import requests # install requests, requests ist eine Python-Bibliothek, die dazu dient, HTTP-Anfragen zu erstellen!!!
import os


# für Statistische berechnungen 
from statistics import median

# Hier werden die Verwendeten Variablen definiert meist int(), float()

# Statistik_Oxid_Gewichtung
masse_oxid = int() or float() or list()
ges_masse = int() or float() or list()

# Statistik_Element_Gewichtung
masse_element = int or float or list()

# Standardabweichung
datensatz = int() or list()
atommassen_datensatz = []

# Umrechnung von Oxid-Gew% in Element-Gew%
masse_oxid = int() or float() or list()
molare_masse_element = float() or list()

# berechnung von delta-werten von Isotopen
probe_ratio = int() or float()
standard_ratio = int() or float()

# berechnung Modalbestand # Gestein magmaren_reservoir
X = float() or int()
c = float() or int()
d = float() or int()

# oxid_prozent_zu_element_prozent_dataframe
# Bespiel an oxelconv
df = mg.get_data("oxelconv")


def export_und_download():
    df_input = input("Welche Datei möchten Sie aus dem Ordner mag4datasets downloaden?: ")
    df = data.get_data(df_input)

    # Hier wird das DataFrame in eine CSV-Datei exportiert
    csv_filename = 'exportierte_daten.csv'
    df.to_csv(csv_filename, index=False)

    print('Daten wurden in {csv_filename} exportiert.')

    # die CSV-Datei wird herunterladen
    # (lokaler Pfad) zu einem anderen Ziel kopieren, erstellt einen pfad zum abspeichern
    downloaded_csv_filename = 'heruntergeladene_daten.csv'
    import shutil # Das Package bietet die  Funktionen zum Kopieren und Verschieben, sowie Löschen von Dateien und Verzeichnissen
    shutil.copy(csv_filename, downloaded_csv_filename)

    print('Datei wurde heruntergeladen und gespeichert unter: {downloaded_csv_filename}')
    
    return export_und_download

export_und_download()

def scatterplot_dataframe(dataframe):
    # mg.available_datasets()
    # df = mg.get_data("mcdis")
    # df
    
    # Überprüfen, ob das DataFrame nicht leer ist, wenn ja dann return
    if dataframe.empty:
        print("Das DataFrame ist leer.")
        return

    # Liste der verfügbaren Spaltennamen für Dropdown-Menüs erstellen
    spalten_liste = list(dataframe.columns)

    # Dropdown-Menüs für X- und Y-Achse erstellen
    dropdown_x = widgets.Dropdown(options = spalten_liste, description = 'X-Achse:')
    dropdown_y = widgets.Dropdown(options = spalten_liste, description = 'Y-Achse:')

    # Funktion zur Aktualisierung des Scatterplots basierend auf Dropdown-Auswahl, mit dem Modul interactive
    @interact(x = dropdown_x, y = dropdown_y)
    def aktualisiere_scatterplot(x, y):
        plt.figure(figsize = (8, 6))
        plt.scatter(dataframe[x], dataframe[y])
        plt.title(f'Scatterplot: {x} vs {y}')
        plt.xlabel(x)
        plt.ylabel(y)
        plt.show()

data = {'X_Achse': [1, 2, 3, 4, 5], # Die Range 1-5 für x
        'Y_Achse': [5, 4, 3, 2, 1]} # Die Range 1-5 für y


def oxid_prozent_zu_element_prozent_dataframe(df):
    oxid_spalten = [spalte for spalte in df.columns if 'oxid' in spalte.lower()]
    oxid_spalten_data = df[oxid_spalten]
    return oxid_spalten_data

oxid_spalten_data = oxid_prozent_zu_element_prozent_dataframe(df) 
# Aufruf über print("Daten der Spalten mit 'oxid':", oxid_spalten_data) # gibt alle Spalten für Oxid aus und deren Daten --> oxide form,  oxide to element,  element to oxide,

def oxid_prozent_zu_element_prozent(masse_oxid, molare_masse_element):
    # umrechnung von oxid% in element%
    if molare_masse_element == 0:
        return None  # Verhindert eine Division durch Null.

    element_prozent = (masse_oxid / molare_masse_element) * 100
    return element_prozent

def magmaren_reservoir_dataframe(dataframe, wert_X, wert_c, wert_d):
    """
    Berechnet das Magmaren Reservoir basierend auf Modalfülle (X), Elementkonzentration (c) und Dichte (d) in einem DataFrame.

    :parameter dataframe: Das DataFrame mit den relevanten Spalten
    :parameter wert_X: Name der Spalte für Modalfülle
    :parameter wert_c: Name der Spalte für Elementkonzentration
    :parameter wert_d: Name der Spalte für Dichte
    :return: Gesamtmenge des Magmaren Reservoirs
    """
    if not all(col in dataframe.columns for col in [wert_X, wert_c, wert_d]):
        raise ValueError("Nicht alle erforderlichen Spalten sind im DataFrame vorhanden.")

    tmp = [] # list()
    for i in range(len(dataframe)):
        res = (dataframe.at[i, wert_X] * dataframe.at[i, wert_d] * dataframe.at[i, wert_c]) / (dataframe.at[i, wert_X] * dataframe.at[i, wert_d])
        tmp.append(res) # elemete hinzufügen!

    magmaren_reservoir_menge = sum(tmp)

    return magmaren_reservoir_menge

    """"

    Aufruf als Bsp. 
    df = mg.get_data("") # Modul aus mag4

    # Spaltennamen anpassen, basierend auf den Daten
    wert_X = "Modalfülle"
    wert_c = "Elementkonzentration"
    wert_d = "Dichte"
    reservoir_menge = magmaren_reservoir_dataframe(df, wert_X, wert_c, wert_d)
    print("Die Gesamtmenge des Magmaren Reservoirs beträgt: {reservoir_menge} Einheiten.")
    """

def gewichtsprozente_für_Reservoir(magmen_mengen):
    # berechnung vom Anteil vom Reservoir Bsp. Magmen Anteile einer Zusammensetzung # Bsp. list()
    summe = sum(magmen_mengen.values())
    gewichtsprozente = {substanz: (masse / summe) * 100 for substanz, masse in magmen_mengen.items()}
    return gewichtsprozente


def modalbestand_gestein_dataframe(dataframe, wert_X, wert_c, wert_d):
    # X: Modalfülle ... c: element konzentration ... d: Dichte  ... der einzelnen Phasen
    tmp = []
    for i in range(len(dataframe)):
        res = (dataframe.at[i, wert_X] * dataframe.at[i, wert_d] * dataframe.at[i, wert_c]) / (dataframe.at[i, wert_X] * dataframe.at[i, wert_d])
        tmp.append(res)
    return sum(tmp)

def Modalbestand_gestein(X, c, d): 
    # Daten als Beispiel, kann überschrieben werden:  # X: Modalfülle ... c: element konzentration ... d: Dichte  ... der einzelnen Phasen
    X = [.24, .53, .04, .19]
    c = [24.49, 2.98, 10.87, 9.38]
    d = [4.12, 2.32, 4.89, 1.01]

    tmp = [] # list()
    for i in range(len(X)):
        res = (X[i] * d[i] * c[i]) / (X[i] * d[i])
        tmp.append(res)
    return sum(tmp)
    

def deltaIsotope_dataframe(dataframe, element, isotope_probe, isotope_standard): 
    # Überprüfen, ob das DataFrame nicht leer ist
    if dataframe.empty:
        return None

    # Überprüfen, ob die benötigten Spalten im DataFrame vorhanden sind
    if element not in dataframe.columns or isotope_probe not in dataframe.columns or isotope_standard not in dataframe.columns:
        print("Fehler: Fehlende Spalten im DataFrame vorhanden")
        return None

    # Berechne Delta-Isotopenwerte
    delta_isotope_werte = ((dataframe[isotope_probe] / dataframe[isotope_standard]) - 1) * 1000

    # Füge die Delta-Isotopenwerte als neue Spalte zum DataFrame hinzu
    dataframe['Delta: ' + element] = delta_isotope_werte

    return dataframe

def deltaIsotope(probe_ratio, standard_ratio):
    # berechnet die delta Werte für Isotope
    delta = ((probe_ratio / standard_ratio) - 1) * 1000
    return delta


# Funktionen welche als import aufgerufen werden können!
def Statistik_Oxid_Gewichtung(masse_oxid, ges_masse):
    # berechnet die oxid-Gew% aus
    if ges_masse != 0:
        oxid_gew = (masse_oxid / ges_masse) * 100
        return oxid_gew
    else:
        print("Fehler: Division durch Null wird vermieden.")
        return None


def Statistik_Element_Gewichtung(masse_element, ges_masse):
    # berechnet die Element-Gew% aus 
    if ges_masse != 0:
        element_gew = (masse_element / ges_masse) * 100
        return element_gew
    else:
        print("Fehler: Division durch wird nicht ausgeführt")
        return None
    

def mittelwert_dataframe(dataframe):
    # Überprüfen, ob das DataFrame nicht leer ist, dann return None
    if dataframe.empty:
        return None

    # die Daten in numerische Werte umzuwandeln, um die Daten als Int(), float zu übergeben
    try:
        dataframe_numeric = dataframe.apply(pd.to_numeric)
    except ValueError:
        print("Fehler: Konnte Daten nicht in numerische Werte umwandeln.")
        return None

    # Mittelwert für jede Spalte berechnen
    mittelwert_pro_spalte = dataframe_numeric.mean()

    return mittelwert_pro_spalte

def mittelwert(datensatz):
    # gibt den Mittelwert vom datensatz aus
    # 
    sum(datensatz) / len(datensatz) # aufzählen die im Datensatz enthaltenen Elemente 
    return


def Standardabweichung_dataframe(dataframe):
   # Überprüfen, ob das DataFrame nicht leer ist sonst = return None
    if dataframe.empty:
        return None

    # Daten in numerische Werte umzuwandeln sonst Fehler abfangen 
    try:
        dataframe_numeric = dataframe.apply(pd.to_numeric)
    except ValueError:
        print("Fehler: Konnte Daten nicht in numerische Werte umwandeln.")
        return None

    # Standardabweichung für jede Spalte berechnen, wenn Spalte Zahlendaten 
    pro_spalte = dataframe_numeric.std()

    return pro_spalte

def Standardabweichung(datensatz):
    # gibt die Standardabweichung vom Datensatz aus
    mittelwert = sum(datensatz) / len(datensatz)
    quadrate_der_abweichungen = [(x - mittelwert) ** 2 for x in datensatz]
    durchschnittliches_quadrat = sum(quadrate_der_abweichungen) / len(datensatz)
    standardabweichung = math.sqrt(durchschnittliches_quadrat)
    return standardabweichung


def median_dataframe(dataframe):
    # Überprüfen, ob das DataFrame nicht leer ist
    if dataframe.empty:
        return None

    # Versuche, die Daten in numerische Werte umzuwandeln
    try:
        dataframe_numeric = dataframe.apply(pd.to_numeric)
    except ValueError:
        print("Fehler: Konnte Daten nicht in numerische Werte umwandeln!!!")
        return None

    # Median für jede Spalte berechnen
    median_pro_spalte = dataframe_numeric.median()

    return median_pro_spalte

def Median(datensatz):
    # gibt den Median vom Datesatz aus
    # datensatz kann im import (Aufruf überschrieben werden) 
    return median(datensatz)


def summe_dataframe(dataframe):
    # Überprüfen, ob das DataFrame nicht leer ist
    if dataframe.empty:
        return None

    # Versuche, die Daten in numerische Werte umzuwandeln
    try:
        dataframe_numeric = dataframe.apply(pd.to_numeric)
    except ValueError:
        print("Fehler: Konnte Daten nicht in numerische Werte umwandeln!!!")
        return None

    # Summe für jede Spalte berechnen
    summe_pro_spalte = dataframe_numeric.sum()

    return summe_pro_spalte

def summe(datensatz):
    # addiert die Anzahl an Elementen in einem Datensatz und gibt den Gesamtwert zurück
    return sum(datensatz)


def min_max_dataframe(dataframe):
    # MIN() Funktion gibt den kleinsten Wert aus einer Reihe von Zahlen zurück.
    # Die MAX() Funktion gibt den größten Wert aus einer Reihe von Zahlen zurück.
    # res = min_max_dataframe(df) und print("Min/Max: ", res), result = (Min/Max-Werte)

    # Überprüfen, ob das DataFrame nicht leer ist
    if dataframe.empty:
        return None, None

    # Bereinigen des DataFrames von Werten die alsStr
    numeric_dataframe = dataframe.apply(pd.to_numeric, errors='coerce')

    # Mindest- und Maximalwerte aus dem bereinigten DataFrame auslesen
    min_wert = numeric_dataframe.min().min()
    max_wert = numeric_dataframe.max().max()

    return min_wert, max_wert

def min_max(datensatz):
    # Überprüfen, ob die Liste nicht leer ist, wenn ja return None
    if not list:
        return None, None

    # Mindest- und Maximalwerte aus der Liste auslesen
    min_wert = min(datensatz)
    max_wert = max(datensatz)

    return min_wert, max_wert


# 1. export_und_download
# In deinem Video hast du erwähnt, dass es sinnvoll wäre csv datein herunterzuladen. Ich habe das im Anschluss implementiert und diese Funktion wird mit dem Befehl: export_und_download() aufgerufen.
# Dabei gibt es einen Input, dort kann man schnell auf csv-Datein in deinem GitHub zugreifen und herunterladen: alle datein im Order mag4datasets/ data/ können abgerufen werden. 
# bei bedarf kann der input durch eine Standard .csv ersätzt werden, für meine Arbeitsweise war das am sinnvollsten. Bei weiteren verwenden kann das jedoch angepasst werden oder überschrieben werden.

# 2. Scatterplot
# Wichtig lade vorher das dataframe um mit mg.get_data("") zu arbeiten!
# Funktion aufrufen, um den Scatterplot mit Dropdown-Menüs zu erstellen
# scatterplot_dataframe(df)

# 3. Funktionen für Statistische Berechnung
# Ich habe alle Funktionen angepasst um mit dataframes zu arbeiten. Dies ist jetzt implementiert und kann für selbst definierte Datensätze verwendet werden oder auch für ein beliebiges DataFrame
# Bsp. Aufruf für einen dataframe z.B an def min_max_dataframe(): 
# pro_spalte = min_max_dataframe(df) # Name der Funktion und der Name vom dataframe
# print("Standardabweichung für jede Spalte:", pro_spalte) # dann wird pro Spalte ausgegeben und dropt min, max

# weitere defs. 
# try, exept um Fehler abzufangen, dabei geht es divisionen durch null als Bsp. oder andere Fehler die zum Abbruch des Programms führen können. 
# apply-Funktion in Pandas ist dafürt da, um eine Funktion auf alle Elemente einer DataFrame-Spalte oder -Zeile anzuwenden!!!